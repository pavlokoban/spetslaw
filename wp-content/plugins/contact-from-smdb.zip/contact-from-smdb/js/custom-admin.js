jQuery(document).ready(function() {
	//alert(wnm_custom.url);
	var t = jQuery('#example').DataTable({
		lengthMenu: [[10, 25, 50, -1], [10, 25, 50, "All"]],
		columnDefs: [ 
			{
            	"searchable": false,
            	"orderable": false,
            	"targets": [0],
        	},
			{
                "targets": [ 1 ],
                "visible": false,
                "searchable": false
            },
			{ "width": "20%", "targets": [1,2,3,4,5] }
		],
		
       // order: [[ 1, 'desc' ]],
		dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ],
		scrollX : true,
		fnRowCallback: function( nRow, aData, iDisplayIndex, iDisplayIndexFull ) {
                    if ( aData[1] == "1" )
                    {
                        $('td', nRow).css('background-color', '#E7A8A8');
                    }
                    
                },
         initComplete: function () {
            this.api().columns([2,3,-2]).every( function () {
                var column = this;
                var select = jQuery('<select><option value=""></option></select>')
                    .appendTo( jQuery(column.footer()).empty() )
                    .on( 'change', function () {
                        var val = jQuery.fn.dataTable.util.escapeRegex(
                            jQuery(this).val()
                        );
 
                        column
                            .search( val ? '^'+val+'$' : '', true, false )
                            .draw();
                    } );
 
                column.data().unique().sort().each( function ( d, j ) {
                    select.append( '<option value="'+d+'">'+d+'</option>' )
                } );
            } );
        } /* */
	});
	
	 t.on( 'order.dt search.dt', function () {
        t.column(0, {search:'applied', order:'applied'}).nodes().each( function (cell, i) {
            cell.innerHTML = i+1;
        } );
    } ).draw();
	
	$('#example').on('click', 'tr', function () {
        var name = $('td', this).eq(1).text();
        $('#DescModal').modal("show");
    });
	
     	
} );