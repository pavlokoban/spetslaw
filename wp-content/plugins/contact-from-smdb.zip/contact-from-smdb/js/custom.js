jQuery(function(){
    "use strict";
	jQuery("input.wpcf7-email").on('keyup ', function() {	
		var eInput = this.value;
		jQuery(this).closest("form").find('input.wpcf7-spam_email').val(eInput);
				
    });
});